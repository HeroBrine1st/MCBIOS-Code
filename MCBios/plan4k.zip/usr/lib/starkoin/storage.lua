local util = require"starkoin.util"
local crypto = require"starkoin.crypto"
local fs = require"filesystem"

local blockSchema = {
    { name = "hash", f = "c16" },
    { name = "source", f = "c128" },
    { name = "target", f = "c128" },
    { name = "amount", f = "j" },
    { name = "previous", f = "c16" },
    { name = "comment_type", f = "B" },
    { name = "BLOB", f = "c127" },
    { name = "sig", f = "c128" }
}
util.initSchemaSize(blockSchema)

local hashSchema = {
    { name = "hash", f = "c16" },
    { name = "position", f = "I4" }
}
util.initSchemaSize(hashSchema)

local storage = {
    chain = nil,
    hashFolder = nil,
    options = {},
    valid = nil,
    walkCallback = function() end,
}

local magicSeq = "StarKoinByMagik6k&Kubuxu"
---local 

storage.schemaSize = blockSchema.size

function storage:create(save)
    assert(save == nil or type(save) == "table", "If save is specified the it has to be table.")
    save = save or {}
    setmetatable(save, self)
    self.__index = self
    return save
end

function storage:init(chain, hashFolder, walkCallback)
    self.chain = fs.open(chain)
    self.hashFolder = hashFolder .. "/"
    self.walkCallback = walkCallback
    self.valid = nil
    self:_genHashTable()
end

function storage:isValid()
    if self.valid ~= nil then
        return self.valid
    end
    self.chain:seek("set", 0)
    local seq = self.chain:read(#magicSeq)
    self.valid = seq == magicSeq
    return self.valid
end

-- scraps current chain (if any) and generates base fro storage of new
function storage:regenerate()
    self.chain:seek("set", 0)
    self.chain:write(magicSeq)
    self.chain:write(string.pack("I4", 0))
    valid = true
end

function storage:import()
    for i = 0, self:getBlockCount() - 1 do
        local block = self:getBlockAt(i)
        self:_addToHashTable(block.hash, i)
        self.walkCallback(block, i)
        
    end
    
end

function storage:getBlockCount()
    self.chain:seek("set", #magicSeq)
    local res = string.unpack("I4", self.chain:read(4))
    print("Block count " .. res)
    return res
end

local function hexComp(a, b)
    -- return a > b
    for i = 1, #a do
        if #b < i then
            -- equal until now but b end and a keeps going
            return true
        end
        local na, nb = tonumber(a:sub(i, i), 16), tonumber(b:sub(i, i), 16)
        if na ~= nb then
            return na > nb
        end
    end
    error("Compare in weird place, this shouldn't happen")
end



function storage:_genHashTable()
    self.hashtable = {}
    --[[fs.remove(self.hashFolder)
    fs.makeDirectory(self.hashFolder)
    self.hashInfo = {}
    local initfiles = "0123456789abcdef"
    for c in initfiles:gmatch(".") do
        table.insert(self.hashInfo, c)
        fs.open(self.hashFolder .. c, "wb"):close()
    end]]--
end


function storage:_addToHashTable(hash, position)
    self.hashtable[hash] = position
    return
    --[[ os.sleep(0)
    print(("Adding to hashtable: %s at %s"):format(crypto.shortHash(hash), position))
    local shash = crypto.toHex(hash)
    for _, hashfile in ipairs(self.hashInfo) do
        --print(shash .. " to " .. hashfile)
        if shash:match("^" .. hashfile) then
            --print("TRY: "..fs.concat(self.hashFolder, hashfile))
            local f = io.open(fs.concat(self.hashFolder, hashfile), "rb")
            local data = f:read("*a")
            f:close()
            for i = 0, #data/hashSchema.size do
                if hash < data:sub(hashSchema.size * i + 1, hashSchema.size * (i + 1)) or #data < hashSchema.size then
                    data = data:sub(1, hashSchema.size * i + 1 - 1)
                        .. string.pack(hashSchema.fmt, hash, position)
                        .. data:sub(hashSchema.size * i + 1, -1)
                    local f = io.open(self.hashFolder .. hashfile, "wb")
                    f:write(data)
                    f:close()
                    return
                end
            end
        end
    end
            
    error("Hash insert in weird place, this shouldn't happen") ]]--
end


local blockOffset = #magicSeq + 4

function storage:addBlock(block)
    local ser = util.packSchema(block, blockSchema)
    
    local curr = self:getBlockCount()
    
    self.chain:seek("set", #magicSeq + 4 + curr * blockSchema.size)
    self.chain:write(ser)
    
    self.chain:seek("set", #magicSeq)
    self.chain:write(string.pack("I4", curr + 1))
    self:_addToHashTable(block.hash, curr)
end

function storage:getBlockAt(index)
    self.chain:seek("set", #magicSeq + 4 + index * blockSchema.size)
    local ser = self.chain:read(blockSchema.size)
    return util.unpackSchema(ser, blockSchema)
end

function storage:getRawBlockAt(index)
    self.chain:seek("set", #magicSeq + 4 + index * blockSchema.size)
    return self.chain:read(blockSchema.size)
end

function storage:getBlockByHash(hash)
    return self:getBlockAt(self.hashtable[hash])
end

function storage:getRawBlockByHash(hash)
    return self:getRawBlockAt(self.hashtable[hash])
end

return storage