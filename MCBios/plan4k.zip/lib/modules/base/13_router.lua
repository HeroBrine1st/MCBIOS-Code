local interfaces = kernel.modules.interface.interfaces
local ip = kernel.modules.ip
local ip4send = ip.ip4send

--route: key -> ip {subnet, via, srcip, interface}
routes4 = {}

local function matchBits(a, pattern, n)
    local full = math.floor(n / 8)
    local rest = n % 8
    
    if a:sub(1, full) ~= pattern:sub(1, full) then
        return false
    end
    
    if rest ~= 0 then
        return (a:byte(full + 1) & (0xff << (8 - rest))) == (pattern:byte(full + 1) & (0xff << (8 - rest)))
    end
    
    return true
end

local function findBest4(to)
    local best = nil
    local bestnet = -1
    for dest, route in pairs(routes4) do
        if route[1] > bestnet and matchBits(to, dest, route[1]) then
            best = route
            bestnet = route[1]
        end
    end
    return best
end

function ip4src(dip)
    local r = findBest4(dip)
    if not r then return nil, "No route to host" end
    return r[3]
end

function ip4sendto(dip, proto, data)
    local r = findBest4(dip)
    if not r then return nil, "No route to host" end
    local rdip = type(r[2]) == "string" and r[2] or nil
    local n, err = ip4send(dip, r[3], proto, data, r[4], rdip)
    if err then
        return nil, err
    end
    return r[3], n
end

function ip4forward(dip, frame) --Sip only for forwarded packets!
    local r = findBest4(dip)
    if not r then return false end
    local rdip = type(r[2]) == "string" and r[2] or nil
    local n = ip.ip4forward(frame, r[4], type(r[2]) == "string" and r[2] or dip)
end

--via can be ethier table for interface or string for ip
function ip4routeAdd(to, subnet, src, via)
    local iface = via
    if type(via) ~= "table" then
        local r = findBest4(via)
        if not r or type(r[2]) ~= "table" then return end
        iface = r[2]
    end
    routes4[to] = {subnet, via, src, iface}
    return routes4[to]
end

function delInterface(iface)
    for k, r in pairs(routes4) do
        if r[4] == iface then
            routes4[k] = nil
        end
    end
end

------


kernel.modules.sysfs.data.net.v4 = {
    route = kernel.modules.sysfs.roFile(function()
        local s = ""
        for a, r in pairs(routes4) do
            s = s .. ip.ip4string(a) .. "/" .. r[1]
            if type(r[2]) == "table" then
                s = s .. " dev " .. r[4].name .. " src " .. ip.ip4string(r[3]) .. "\n"
            else
                s = s .. " via " .. ip.ip4string(r[2]) .. " dev " .. r[4].name .. " src " .. ip.ip4string(r[3]) .. "\n"
            end
        end
        return s
    end),
    route_add = {
        __type = "f",
        write = function(h, data)
            local net, sub, dv, dst, src = data:match("([%d%.]+)/(%d+)%s+([devia]+)%s([^%s]+)%s+src%s+([%d%.]+)")
            
            if not net then
                kernel.io.println("route_add_v4: Invalid format")
                return nil, "Invalid format"
            end
            
            local via
            if dv == "dev" then
                via = interfaces[dst]
                if not via then
                    kernel.io.println("route_add_v4: invalid dst device")
                    return
                end
            elseif dv == "via" then
                via = ip.ip4parse(dst)
                if not via then
                    kernel.io.println("route_add_v4: invalid dst ip format")
                    return
                end
            else
                kernel.io.println("route_add_v4: need to specify ethier via or dev, got " .. dv)
            end
            
            ip4routeAdd(ip.ip4parse(net), tonumber(sub), ip.ip4parse(src), via)
        end
    }
}

