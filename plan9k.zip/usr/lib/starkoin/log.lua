local log = {
    level = 1,
    pring = nil
}

local levels = {
    debug = 0,
    info = 1,
    warn = 2,
    error = 3
}

function log:new(options)
    assert(options == nil or type(options) == "table", "If options is specified the it has to be table.")
    
    options = options or {}
    
    
    if options.level then
        options.level = type(options.level) == "number" and options.level or levels[options.level:lower()] or 1
    end
    
    options.print = options.print or print
    
    setmetatable(options, self)
    self.__index = self
    
    return options
end

do
    for level, e in pairs(levels) do
        local pre = '[' .. level:upper() .. ']: '
        log[level] = function(self, format, ...)
            if e >= self.level then
                self.print(pre .. format:format(...))
            end
        end
    end
end

return log



