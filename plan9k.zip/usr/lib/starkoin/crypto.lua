local d = require("component").data

--assert(d.tier() >= 3, "Assertion failed: Data card has to be atleast tier 3")

local crypto = {}
local seed = "starkoin"

function crypto.md5(data)
    return d.md5(data, seed)
end

function crypto.sha256(data)
    return d.sha256(data, seed):sub(1,16)
end

local function keyForAES(base)
    return crypto.md5(base)
end

local function genIV()
    return d.random(16)
end

local function encryptAES(data, key)
    if not data then
        return nil , "data is nil"
    end
    if not key then
        return nil , "key is nil"
    end
    
    local IV = genIV()
    local enc = d.encrypt(data, key, IV)
    local crc = d.crc32(data)
    return IV .. enc .. crc
end

local function decryptAES(data, key)
    if not data then
        return nil , "data is nil"
    end
    if not key then
        return nil , "key is nil"
    end
    
    local IV = data:sub(1, 16)
    
    if (not IV) or #IV ~= 16 then
        return nil, "wrong IV"
    end
    
    local enc = data:sub(17, -5)
    local crc = data:sub(-4, -1)
    
    if (not crc) or #crc ~= 4 then
        return nil, "wrong crc"
    end
    
    
    local dec = d.decrypt(enc, key, IV)
    if not dec then
        return nil, "decryption failed"
    elseif d.crc32(dec) ~= crc then
        return nil, "wrong checksum" 
    else
        return dec
    end
end

    
function crypto.encryptPass(data, password)
    return encryptAES(data, keyForAES(password))
end

function crypto.decryptPass(data, password)
    return decryptAES(data, keyForAES(password))
end

local function getShared(private_s, public_s)
    local private = d.deserializeKey(private_s, "ec-private")
    local public = d.deserializeKey(public_s, "ec-public")
    
    if not private then
        return nil, "Private key could not be created"
    end
    if not public then
        return nil, "Public key could not be created"
    end
    
    return keyForAES(d.ecdh(private, public))
end

local function getSharedSmart(card, public_s)
    return keyForAES(card.ecdh(public_s))
end

function crypto.encryptShared(data, private_s, public_s)
    local shared, reason = getShared(private_s, public_s)
    if not shared then
        return nil, reason
    end
    
    return encryptAES(data, shared) 
end

function crypto.encryptSharedSmart(data, card, public_s)
    local shared, reason = getSharedSmart(card, public_s)
    if not shared then
        return nil, reason
    end
    
    return encryptAES(data, shared) 
end

function crypto.decryptShared(data, private_s, public_s)
    local shared, reason = getShared(private_s, public_s)
    if not shared then
        return nil, reason
    end
    
    return decryptAES(data, shared)
end

function crypto.decryptSharedSmart(data, card, public_s)
    local shared, reason = getSharedSmart(card, public_s)
    if not shared then
        return nil, reason
    end
    
    return decryptAES(data, shared)
end

function crypto.pad(str, to, with)
    local with = with or '\0'
    return str .. with:rep(to-#str)
end
local pad = crypto.pad

function crypto.generateKeyPair()
    local public, private = d.generateKeyPair()
    return pad(public.serialize(), 128), pad(private.serialize(), 128)
end

function crypto.sign(message, private_s)
    local private = d.deserializeKey(private_s, "ec-private")
    
    local sign = d.ecdsa(message, private)
    return pad(sign, 128)
end

function crypto.signSmart(message, card)
    local sign = card.ecdsa(message)
    return pad(sign, 128)
end

function crypto.checkSign(message, public_s, sign)
    local public = d.deserializeKey(public_s, "ec-public")
    
    return d.ecdsa(message, public, sign)
end

local function sixteen(val)
    if val < 10 then
        return string.char(48 + val)
    else
        return string.char(97 + val - 10)
    end
end

function crypto.fromHex(hex)
    local res = ""
    for i = 1, #hex/2 do
        res = res .. string.char(tonumber(hex:sub(2*i-1, 2*i), 16))
    end
    return res
end

function crypto.shortHash(bin)
    return crypto.toHex(bin):sub(1,8)
end

function crypto.toHex(bin)
    local res = ""
    for i = 1, #bin do
        local byte = bin:byte(i)
        res = res .. sixteen(byte >> 4) .. sixteen(byte & 0x0F)
    end
    return res
end

return crypto
