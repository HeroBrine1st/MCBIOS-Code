local data = require("component").data
local component = require("component")
local crypto = require("starkoin.crypto")
local event = require("event")
local term = require("term")

local util = {}

do
    
    --  Sample schema:
    --  {
    --      { name = "username", format = "z" }
    --      { n    = "password", f      = "s" }
    --      { "height", "j" }
    --  }
    local function getFMT(schema)
        if schema.fmt then
            return schema.fmt
        end
        local fmt = ""
        for _, v in ipairs(schema) do
            fmt = fmt .. (v.format or v.f or v[2])    
        end
        schema.fmt = fmt
        return fmt
    end
    function util.initSchemaSize(schema)
        schema.size = string.packsize(getFMT(schema))
    end
        
    function util.packSchema(array, schema)
        local packed = {}
        
        for _, v in ipairs(schema) do
            table.insert(packed, array[v.name or v.n or v[1]])
        end
        return string.pack(getFMT(schema), table.unpack(packed, 1, #schema))
    end
    
    function util.unpackSchema(data, schema)
        local unpacked = table.pack(string.unpack(getFMT(schema), data))
        if unpacked.n -1 ~= #schema then
            return nil, "in schema each name must correspond to one and only one value from string.unpack"
        end
        
        local res = {}
        for i, v in ipairs(schema) do
            res[v.name or v.n or v[1]] = unpacked[i]
        end
        
        return res, unpacked[unpacked.n]
    end
    
end

function util.pad(str, to, with)
    local with = with or '\0'
    return str .. with:rep(to-#str)
end

function util.randomInt()
    return math.random(math.mininteger, math.maxinteger) | 0
end

function util.readAll(file)
    local f = io.open(file, "r")
    if not f then
        return nil
    end
    local content = f:read("*all")
    f:close()
    return content ~= "" and content
end


---------------------
-- NFC
---------------------

function util.readNfc(nfc)
    --TODO: event locking
    if component.isAvailable("smartcard_terminal") and component.smartcard_terminal.hasCard() then
        return component.smartcard_terminal
    end
    local user, data
    repeat
        local e, dev, _user, _data = computer.pullSignal()
        if e == "nfc_data" then
            if not nfc or dev:match("^" .. nfc) then
                user = _user
                data = _data
                return data, user
            end
        end
        if e == "smartcard_in" then
            return component.proxy(dev)
        end
    until data
    return data, user
end

function util.writeNfc(data)
    component.NFCProgrammer.writeNFCData(data)
    while component.NFCProgrammer.isDataWaiting() do os.sleep(1)end
end

---------------------
-- Keys
---------------------

local baseKeySchema = {
    {"encrypted", "B"},
    {"data", "s2"}
}

local keySchema = {
    {"type", "B"},
    {"key1", "c128"},
    {"key2", "c128"}
}

local splitSchem = {
    {"part", "B"},
    {"pass", "c64"},
    {"data",  "s2"}
}

function util.readKey(data, file, nfc)
    data = (not file and data) or (file and util.readAll(data))
    local user = nil
    if not data then
        data, user = util.readNfc(nfc)
    end
    if type(data)  == "table" then
        return "smart", crypto.pad(data.getPublicKey(), 128), data
    end
    local r r, data = pcall(util.unpackSchema, data, baseKeySchema)
    if not r then
        print("Invalid raw schema")
        return
    end
    if data.encrypted == 1 then
        print("Key password:")
        local pass = term.read(nil, nil, nil, "*")
        data = crypto.decryptPass(data.data, pass)
    
    elseif data.encrypted == 2 then
        print("Key 1 password:")
        local r, part1 = pcall(util.unpackSchema, crypto.decryptPass(data.data, term.read(nil, nil, nil, "*")), splitSchem)
        if r then
            print("Provide second key")
            local r, data2 = pcall(util.unpackSchema, util.readNfc(nfc), baseKeySchema)
            if r then
                print("Key 2 password:")
                local r, part2 = pcall(util.unpackSchema, crypto.decryptPass(data2.data, term.read(nil, nil, nil, "*")), splitSchem)
                if r then
                    print("Decrypting key")
                    local pass = ("\0"):rep(96)
                    local function applyPart(part)
                        if part.part == 0 then
                            pass = part.pass .. pass:sub(65)
                        elseif part.part == 1 then
                            pass = pass:sub(1, 32) .. part.pass
                        else
                            pass = part.pass:sub(1,32) .. pass:sub(33, 64) .. part.pass:sub(33)
                        end
                    end
                    applyPart(part1)
                    applyPart(part2)
                    data = crypto.decryptPass(part1.data, pass)
                    if not data then
                        error("Couldn't decrypt key!")
                    end
                end
            end
        end
    else
        data = data.data
    end
    local r, key = pcall(util.unpackSchema, data, keySchema)
    if not r then print("Invalid key schema") end
    return r and key.type, r and key.key1 or key, r and key.key2, user
end

function util.storableKey(keytype, key1, key2)
    return util.packSchema({type = keytype, key1 = key1, key2 = key2}, keySchema)
end



return util
