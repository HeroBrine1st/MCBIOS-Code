local util = require("starkoin.util")
local fs = require("filesystem")
local term = require("term")
local crypto = require("starkoin.crypto")
local serialization = require("serialization")
local network = require("network")
local event = require("event")

local starkoin = {}

----
---- TODO: We could generate local key for encryption of session data, to protect it from app
----

---------------------
-- Config
---------------------

local function createConfig()
    print("\n\x1b[31mNo config detected, need to setup bank server connectivity\x1b[39m")
    print("Enter bank server address: ")
    local addr = term.read()
    
    print("Use reader to insert bank public key")
    local keytype, key = util.readKey()
    
    if keytype ~= 1 then
        print("Invalid key("..tostring(keytype)..")")
        return
    end
    
    local config = {
        bankKey = key,
        bankAddr = addr
    }
    
    return config
end

function starkoin.readConfig(createIfNotExists)
    if not fs.exists("~/.starkoin") then
        if createIfNotExists then
            local config
            repeat
                config = createConfig()
            until config
            
            local transFile = io.open("~/.starkoin", "w")
            transFile:write(serialization.serialize(config))
            transFile:close()
        else
            return
        end
    end
    return serialization.unserialize(util.readAll("~/.starkoin"))
end

---------------------
-- Interaction
---------------------

local function accountsetup()
    print("\x1b[33mCreating new account\x1b[39m")
    
    local public, private = crypto.generateKeyPair()
    keytype = 0
    
    print("Do you want to password protect your key(Yes/No/Abort)?")
    local pass
    local entry = term.read():lower():sub(1,1)
    if entry == "a" then os.exit() return end
    if entry == "y" then
        print("Key password:")
        pass = term.read(nil, nil, nil, "*")
    end
    
    local data = string.pack("Bc128c128", 0, public, private)
     if pass then
        data = crypto.encryptPass(data, pass)
        data = string.pack("Bs2", 1, data)
    else
        data = string.pack("Bs2", 0, data)
    end
    
    print("Use NFC card on programmer to set private key")
    util.writeNfc(data)
    return public, private
end

---------------------
-- Session
---------------------

local api = {}

function starkoin.session(private, public, interactive)
    local card
    if not private or not public then
        local keytype, _public, _private = util.readKey("~/.staraccount", true)
        if keytype == "smart" then
            public = _public
            card = _private
        elseif keytype ~= 0 and interactive then
            public, private = accountsetup()
        elseif keytype ~= 0 then
            return
        else
            public = _public
            private = _private
        end
        
    end
    
    local config = starkoin.readConfig(true)

    if not config then
        print("NO CONFIG!!")
        os.exit()
    end
    return setmetatable({config = config, private = private, public = public, card = card}, {__index = api})
end

---------------------
-- Network
---------------------

local clinetPacketSchema = {
    {"rport", "I2"},
    {"version", "B"},
    {"operation", "z"},
    {"args", "s"}
}

local serverPacketSchema = {
    {"version", "B"},
    {"operation", "z"},
    {"args", "s"}
}

local blockSchema = {
    { name = "hash", f = "c16" },
    { name = "source", f = "c128" },
    { name = "target", f = "c128" },
    { name = "amount", f = "j" },
    { name = "previous", f = "c16" },
    { name = "comment_type", f = "B" },
    { name = "BLOB", f = "c127" },
    { name = "sig", f = "c128" }
}
util.initSchemaSize(blockSchema)

local function sendRecvPacket(session, operation, args) --TODO: check recvd operation
    local udp = network.open()
    local data = util.packSchema({rport = udp.port, version = 1, operation = operation, args = args}, clinetPacketSchema)
    if session.private then
        data = crypto.encryptShared(data, session.private, session.config.bankKey)
    else
        data = crypto.encryptSharedSmart(data, session.card, session.config.bankKey)
    end
    
    
    udp:write(network.resolve(session.config.bankAddr), 8333, crypto.sha256(session.public .. data) .. session.public .. data)
    
    local deadline = computer.uptime() + 10
    
    local e, replier, res_port, rawdata
    repeat
        e, replier, sprot, res_port, rawdata = event.pull(deadline - computer.uptime(), "udp_message")
    until computer.uptime() >= deadline or (e == "udp_message" and res_port == udp.port)
    
    if not e then
        udp:close()
        return nil, "Timeout"
    else
        if crypto.sha256(rawdata:sub(17)) ~= rawdata:sub(1, 16) then
            udp:close()
            return nil, "Got malformed response packet"
        end
        local data = rawdata:sub(17)
        local reason
        if session.private then
            data, reason = crypto.decryptShared(data, session.private, session.config.bankKey)
        else
            data, reason = crypto.decryptSharedSmart(data, session.card, session.config.bankKey)
        end
        if not data then
            udp:close()
            return nil, "Decryption failed: ".. reason
        end
        
        local data, reason = util.unpackSchema(data, serverPacketSchema)
        udp:close()
        
        if not data then
            print(reason)
            return data, reason
        end
        
        return data
    end
end

function api:ping()
    local packed = string.pack("j", util.randomInt())
    local res = sendRecvPacket(self, "ping", packed)
    return res and res.args == packed
end

function api:register(name)
    local packed = string.pack("c128s1", self.public, name)
    local res = sendRecvPacket(self, "register", packed)
    return res and res.args == "\1"
end

function api:key(name)
    local packed = string.pack("s1", name)
    local res = sendRecvPacket(self, "key", packed)
    return res and res.args
end

function api:name(key)
    local res = sendRecvPacket(self, "name", key)
    return res and string.unpack("s1", res.args)
end

function api:chain()
    local res = sendRecvPacket(self, "chain", "")
    return res and res.args
end

function api:transferKey(to, amount, comment)
    local chain = self:chain()
    if not chain then
        return false, "Cannot get last chain"
    end
    
    local transaction = string.pack("c128c128jc16Bc127", self.public, to, amount, chain, 0, util.pad(comment, 127))
    local sig
    if self.private then
        sig = crypto.sign(transaction, self.private)
    else
        sig = crypto.signSmart(transaction, self.card)
    end
    local res = sendRecvPacket(self, "transaction", transaction .. sig)

    return res and (res.args == 0)
end

function api:transfer(to, amount, comment)
    to = self:key(to)
    if not to then
        return false, "Cannot get destination key"
    end
    
    return self:transferKey(to, amount, comment)
end

function api:balance(key)
    key = key or self.public
    local res = sendRecvPacket(self, "balance", key)
    return res and string.unpack("j", res.args)
end

function api:operations()
    local res = sendRecvPacket(self, "operations", "")
    if not res then return end
    local rawto, rawfrom = string.unpack("c256c256", res.args)
    local to = {}
    local from = {}
    
    for i=1, 16 do
        local hash = rawto:sub((i-1)*16+1, (i-1)*16+16)
        if hash == ("\0"):rep(16) then break end
        to[#to + 1] = hash
    end
    
    for i=1, 16 do
        local hash = rawfrom:sub((i-1)*16+1, (i-1)*16+16)
        if hash == ("\0"):rep(16) then break end
        from[#from + 1] = hash
    end
    return to, from
end

function api:hash(hash)
    local res = sendRecvPacket(self, "hash", string.pack("c16", hash))
    if not res then return end
    return util.unpackSchema(res.args, blockSchema)
end

function api:since(hash)
    local res = sendRecvPacket(self, "since", string.pack("c16", hash))
    if not res then return end
    local n, nx = string.unpack("B", res.args)
    res = {}
    for i=1, n do
        res[#res + 1], nx = string.unpack("c16", nx)
    end
    return res
end

return starkoin
